package com.example.aftertestbt;

import android.content.Context;
import android.content.Intent;
import android.os.Vibrator;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static android.speech.SpeechRecognizer.ERROR_AUDIO;
import static android.speech.SpeechRecognizer.isRecognitionAvailable;

public class Main2Activity extends AppCompatActivity {

    int color = 0;
    int tailleBoucleEnv;
    int count = 0;
    int IndexItemSupp;
    int choix = 0;
    int b =0;
    int tempo = 0;

    String NumID = "";
    String name = "";
    String str = "";
    String messageAckno = "";
    String conf = "";
    String chaineEnvoie = "";
    String[] splitStr = new String[3];

    boolean vibration;
    boolean stopLect = false;
    boolean check = false;
    boolean actuListe = false;
    boolean notFind = false;

    byte[] bufferEnv = new byte[100];
    byte[] bufferLect = new byte[100];

    Vibrator vib;

    ListView liste;
    ItemAdaptater IA;
    List<ItemModel> LItem = new ArrayList<ItemModel>();

    ArrayList<String> NumId = new ArrayList<>();
    ArrayList<String> NameId = new ArrayList<>();
    ArrayList<Integer> ColorId = new ArrayList<>();

    Intent intentSpeech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

    String Heure(){
        Date date = new Date();
        SimpleDateFormat formatDate = new SimpleDateFormat("HH:mm:ss");
        return formatDate.format(date);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_DOWN) {
                    MethodeSendVoice();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast t = Toast.makeText(getApplicationContext(), "Volume haut", Toast.LENGTH_LONG);
                            t.show();
                        }
                    });
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN) {
                    MethodeSendVoice();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast t = Toast.makeText(getApplicationContext(), "Volume bas", Toast.LENGTH_LONG);
                            t.show();
                        }
                    });
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                if (action == KeyEvent.ACTION_DOWN) {
                    MethodeSendVoice();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast t = Toast.makeText(getApplicationContext(), "Volume mute", Toast.LENGTH_LONG);
                            t.show();
                        }
                    });
                }
                return true;
            default:
                Toast.makeText(getApplicationContext(), String.valueOf(keyCode), Toast.LENGTH_LONG).show();
                return true;
                //return super.dispatchKeyEvent(event);
        }
    }

    /*void MethodeCheckEnvoi(final String message){
        bufferEnv = message.getBytes(Charset.defaultCharset());
        try {
            MainActivity.m.write(bufferEnv);
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }*/

    void MethodeConfiguration(String name, int color, int tempo){
        int g = (int)(Math.random()*50 + 1);
        NumID = String.valueOf(g);
        conf = "CoNfIg" + ":" + String.valueOf(g) + ":" + name + ":" + color + ":" + tempo;
        bufferEnv = conf.getBytes(Charset.defaultCharset());
        try {
            MainActivity.m.write(bufferEnv);
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), "Configuration OK", Toast.LENGTH_LONG).show();
            }
        });
    }

    void MethodeEnvoie(final String message){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    tailleBoucleEnv = message.length();
                    if (tailleBoucleEnv > 50) {
                        double r = tailleBoucleEnv / 50;
                        int rbis = (int) r;
                        int n = 0, m = 0;
                        String x = "DeBuT";

                        bufferEnv = x.getBytes(Charset.defaultCharset());
                        try{
                            MainActivity.m.write(bufferEnv);
                        }catch (Exception e){
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                        }

                        Thread.sleep(3000);

                        for (int i = 0; i < rbis; i++) {
                            m = m + 50;
                            CharSequence chaine = NumID + ":" + message.subSequence(n, m);
                            bufferEnv = chaine.toString().getBytes(Charset.defaultCharset());
                            try{
                                MainActivity.m.write(bufferEnv);
                            }catch(Exception e){
                                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                            }
                            //LItem.add(new ItemModel(Heure() + " " + name, String.valueOf(message.subSequence(n, m)), "En cours", color));
                            chaineEnvoie = chaineEnvoie.concat(String.valueOf(message.subSequence(n, m)));

                            n = n + 50;
                            Thread.sleep(3000);
                        }
                        CharSequence chaineEnd = NumID + ":" + message.subSequence(m, message.length());
                        bufferEnv = chaineEnd.toString().getBytes(Charset.defaultCharset());
                        try{
                            MainActivity.m.write(bufferEnv);
                        }catch(Exception e){
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                        }
                        //LItem.add(new ItemModel(Heure() + " " + name, String.valueOf(message.subSequence(m, message.length())), "En cours", color));
                        chaineEnvoie = chaineEnvoie.concat(String.valueOf(message.subSequence(m, message.length())));
                        LItem.add(0, new ItemModel(Heure() + " " + name, chaineEnvoie, "En cours", color));
                        chaineEnvoie = "";

                        Thread.sleep(2000);
                        x = "FiN";
                        bufferEnv = x.getBytes(Charset.defaultCharset());
                        try{
                            MainActivity.m.write(bufferEnv);
                        }catch (Exception e){
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        check = false;
                        //messageAckno = message;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    //split = message.split(":");
                                    //messageAckno = split[1];
                                    messageAckno = message;
                                    LItem.add(0, new ItemModel(Heure() + " " + name, message, "En cours", color));
                                    IndexItemSupp = LItem.size()-1;
                                    liste.setAdapter(IA);
                                }catch (Exception e){
                                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                                }
                            }
                        });

                        messageAckno = NumID + ":" + message;
                        bufferEnv = messageAckno.getBytes(Charset.defaultCharset());
                        try{
                            MainActivity.m.write(bufferEnv);
                        }catch(Exception e){
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                        }
                        //check = true;
                        while (check){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "Attente akno", Toast.LENGTH_LONG).show();
                                }
                            });

                            try{
                                Thread.sleep(5000);
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                            }
                        }
                    }

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        liste.setAdapter(IA);
                    }
                });
            }
        }).start();
    }

    void MethodeSendVoice(){
        if(isRecognitionAvailable(getApplicationContext())){
            try {
                intentSpeech.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                intentSpeech.putExtra(RecognizerIntent.EXTRA_PROMPT, "PARLER...");

                startActivityForResult(intentSpeech, 50);

                onActivityResult(50, RESULT_OK, intentSpeech);

            }catch(Exception e){
                e.toString();
                Toast t = Toast.makeText(getApplicationContext(), "Result: " + e, Toast.LENGTH_LONG);
                t.show();
            }
        }
    }

    void Lecture(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                stopLect = true;
                while (stopLect) {
                    try{
                        if(MainActivity.l.available() != 0)
                            b = MainActivity.l.read(bufferLect);
                        else
                            b = -1;
                    }catch (Exception e){
                       // Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                    str = new String(bufferLect, Charset.defaultCharset());

                    if(b != -1) {
                        actuListe = true;
                        if(vibration)
                            vib.vibrate(250);
                        splitStr = str.trim().split(":", 5);
                        if(splitStr[0].equals("CoNfIg")){
                            try {
                                NumId.add(count, splitStr[1]);
                                NameId.add(count, splitStr[2]);
                                ColorId.add(count, Integer.decode(splitStr[3]));
                                tempo = Integer.decode(splitStr[4]);
                                LItem.add(0, new ItemModel("", "Configuration :" + NameId.get(count) + " OK", "", ColorId.get(count)));
                                count++;
                            }catch(Exception e){
                                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                            }
                        }
                        else if(str.trim().equals("1")) {
                            check = false;
                            LItem.remove(IndexItemSupp);
                            LItem.add(IndexItemSupp, new ItemModel(Heure() + " " + name, messageAckno, "Confirmé", color));
                        }else{
                            choix = 0;
                            notFind = true;
                            //MethodeCheckEnvoi("Acknow");
                            for(int i = 0; i <= splitStr.length - 1; i++) {
                                if(splitStr[0].equals(NumId.get(choix))) {
                                    LItem.add(0, new ItemModel(Heure() + " " + NameId.get(choix), splitStr[1], "Reçu", ColorId.get(choix)));
                                    notFind = false;
                                }else
                                    notFind = true;
                                choix++;
                            }

                            if(notFind){
                                LItem.add(0, new ItemModel(Heure(), str, "Reçu", 0));
                                notFind = false;
                            }
                        }
                        for(int i = 0; i < bufferLect.length; i++){
                            bufferLect[i] = 0;
                        }
                    }

                    if(actuListe) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                liste.setAdapter(IA);
                            }
                        });
                        actuListe = false;
                    }

                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                }
            }
        }).start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        Intent intent = getIntent();
        color = intent.getIntExtra("color", 0);
        name = intent.getStringExtra("name");
        vibration = intent.getBooleanExtra("vibration", false);
        tempo = Integer.decode(intent.getStringExtra("Temporisation"));

        Toast.makeText(getApplicationContext(), name + String.valueOf(color) + String.valueOf(vibration) + tempo, Toast.LENGTH_LONG).show();

        liste = findViewById(R.id.ListeMessage);

        //Initialisation des arrays
        for(int i = 0; i <= 3; i++){
            NumId.add(i, " ");
            NameId.add(i, " ");
            ColorId.add(i, 0);
        }

        IA = new ItemAdaptater(Main2Activity.this, LItem);
        liste.setAdapter(IA);

        Lecture();
        MethodeConfiguration(name, color, tempo);

        /*Button stop = findViewById(R.id.Stop);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check = false;
                stopLect = false;
                try{
                    MainActivity.bluetoothSocket.close();
                    Thread.sleep(3000);
                    finish();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });*/

        Button Test = findViewById(R.id.Test);
        Test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MethodeConfiguration(name, color, tempo);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 50: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    Toast.makeText(getApplicationContext(), result.get(0), Toast.LENGTH_LONG).show();
                    String inter = result.get(0);
                    MethodeEnvoie(/*NumID + ":" + */inter);
                }else if(resultCode == ERROR_AUDIO){
                    this.finish();
                }
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        try{
            check = false;
            stopLect = false;
            MainActivity.bluetoothSocket.close();
            Thread.sleep(300);
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
        super.onBackPressed();
    }
}
