package com.example.aftertestbt;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements OnItemSelectedListener {

    int color = 0;

    boolean Vibration = false;

    public volatile Spinner spin;
    public volatile ArrayAdapter<CharSequence> adapterSpin;

    int REQUEST_ENABLE_BT = 0;
    int REQUEST_ACTIVITY = 3;

    BluetoothAdapter bluetoothAdapter;
    static BluetoothSocket bluetoothSocket;

    TextView VerifPerm;

    static OutputStream m = null;
    static InputStream l = null;

    Intent enableBtIntent;
    Intent intent;

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position){
            case 0:
                //onNothingSelected(parent);
                break;

            case 1:
                color = 0xFFF75A5A;
                spin.setBackgroundColor(color);
                break;

            case 2:
                color = 0xFF4691FF;
                spin.setBackgroundColor(color);
                break;

            case 3:
                color = 0xFFC0FF46;
                spin.setBackgroundColor(color);
                break;
            case 4:
                color = 0xFFF188B8;
                spin.setBackgroundColor(color);
                break;
            case 5:
                color = 0xFFCAB25C;
                spin.setBackgroundColor(color);
                break;
            case 6:
                color = 0xFFFFFA67;
                spin.setBackgroundColor(color);
                break;
            default:
                Toast tbiss = Toast.makeText(getApplicationContext(), "Autre", Toast.LENGTH_LONG);
                tbiss.show();
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast t = Toast.makeText(getApplicationContext(), "Choisir une couleur !", Toast.LENGTH_LONG);
        t.show();
    }

    void BT_ON(){
        VerifPerm.setText("Permission Denied");
        VerifPerm.setTextColor(0xFFFF0000);
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }

    void ConfigurationBT(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(bluetoothAdapter.isEnabled()){
                    Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

                    if (pairedDevices.size() > 0) {
                        // There are paired devices. Get the name and address of each paired device.
                        for (BluetoothDevice device : pairedDevices) {
                            String deviceName = device.getName();
                            //String deviceHardwareAddress = device.getAddress(); // MAC address

                            if (deviceName.equals("HC-05-MONITEUR")) {
                                ConnectThread connect = new ConnectThread(device);
                                connect.run();
                                bluetoothSocket = connect.thisSocket;
                                if(connect.thisSocket.isConnected()){
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            VerifPerm.setText("Connection Réussite");
                                            VerifPerm.setTextColor(0xFF00FF00);
                                        }
                                    });

                                    try {
                                        m = connect.thisSocket.getOutputStream();
                                        l = connect.thisSocket.getInputStream();

                                    }catch(Exception e){
                                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                                    }
                                }else {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            VerifPerm.setText("Echec Connection");
                                            VerifPerm.setTextColor(0xFFFF0000);
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }).start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        intent = new Intent(MainActivity.this, Main2Activity.class);
        enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

        final Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        spin = findViewById(R.id.Spin);
        final EditText edit = findViewById(R.id.TexteName);
        final EditText editTempo = findViewById(R.id.Temporisation);

        adapterSpin = ArrayAdapter.createFromResource(this, R.array.Choose_Color, R.layout.spin_item);

        spin.setAdapter(adapterSpin);

        spin.setOnItemSelectedListener(this);

        VerifPerm = findViewById(R.id.ValidationPerm);

        //Pour fermer keyboard
        View v = findViewById(R.id.Relay);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getCurrentFocus() != null) {
                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                }
            }
        });

        //Sauvegarde textes edit
        final SharedPreferences prefs = getSharedPreferences("Preferences", Context.MODE_PRIVATE);
        final SharedPreferences.Editor ed = prefs.edit();

        edit.setText(prefs.getString("Name", ""));
        editTempo.setText(prefs.getString("Tempo", ""));

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                ed.putString("Name", s.toString()).apply();
            }
        });

        editTempo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                ed.putString("Tempo", s.toString()).apply();

            }
        });

        BT_ON();

        final Switch swit = findViewById(R.id.Vib);
        swit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(!swit.isChecked() && event.getAction() == MotionEvent.ACTION_UP) {
                    Vibration = true;
                    vib.vibrate(300);
                }
                else
                    Vibration = false;
                return false;
            }
        });

        Button SwitchActi = findViewById(R.id.Start);
        SwitchActi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    intent.putExtra("name", edit.getText().toString());
                    intent.putExtra("color", color);
                    intent.putExtra("vibration", Vibration);
                    intent.putExtra("Temporisation", editTempo.getText().toString());
                    startActivityForResult(intent, REQUEST_ACTIVITY);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        Button Bluetooth = findViewById(R.id.blue);
        Bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if(bluetoothAdapter.isEnabled()){
                            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

                            if (pairedDevices.size() > 0) {
                                // There are paired devices. Get the name and address of each paired device.
                                for (BluetoothDevice device : pairedDevices) {
                                    String deviceName = device.getName();
                                    //String deviceHardwareAddress = device.getAddress(); // MAC address

                                    if (deviceName.equals("HC-05-MONITEUR")) {
                                        ConnectThread connect = new ConnectThread(device);
                                        connect.run();
                                        bluetoothSocket = connect.thisSocket;
                                        if(connect.thisSocket.isConnected()){
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    VerifPerm.setText("Connection Réussite");
                                                    VerifPerm.setTextColor(0xFF00FF00);
                                                }
                                            });

                                            try {
                                                m = connect.thisSocket.getOutputStream();
                                                l = connect.thisSocket.getInputStream();

                                            }catch(Exception e){
                                                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                                            }
                                        }else {
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    VerifPerm.setText("Echec Connection");
                                                    VerifPerm.setTextColor(0xFFFF0000);
                                                }
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                }).start();
            }
        });
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket thisSocket;
        private final BluetoothDevice thisDevice;

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            thisDevice = device;

            try {
                tmp = thisDevice.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"));
            } catch (IOException e) {
                Log.e("TEST", "Can't connect to service");
            }
            thisSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it otherwise slows down the connection.
            bluetoothAdapter.cancelDiscovery();

            try {
                thisSocket.connect();
                Log.d("TESTING", "Connected to shit");
            } catch (IOException connectException) {
                try {
                    thisSocket.close();
                } catch (IOException closeException) {
                    Log.e("TEST", "Can't close socket");
                }
                return;
            }

            bluetoothSocket = thisSocket;

        }
        public void cancel() {
            try {
                thisSocket.close();
            } catch (IOException e) {
                Log.e("TEST", "Can't close socket");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_ENABLE_BT){
            if(resultCode == RESULT_OK){
                ConfigurationBT();
            }else{
                BT_ON();
            }
        }

        if(requestCode == REQUEST_ACTIVITY){
            if(bluetoothAdapter.isEnabled())
                ConfigurationBT();
            else
                BT_ON();
        }
    }
}
