package com.example.aftertestbt;

public class ItemModel {
    private String one;
    private String two;
    private String three;
    private int four;

    public ItemModel(String one, String two, String three, int four){
        this.one = one;
        this.two = two;
        this.three = three;
        this.four = four;
    }

    public String getOne() {
        return one;
    }
    public void setOne(String one) {
        this.one = one;
    }

    public String getTwo() {
        return two;
    }
    public void setTwo(String two) {
        this.two = two;
    }

    public void setThree(String three) {
        this.three = three;
    }
    public String getThree() {
        return three;
    }

    public void setFour(int four) {
        this.four = four;
    }
    public int getFour() {
        return four;
    }
}