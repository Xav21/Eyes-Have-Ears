package com.example.EyesHaveEarsMoniteur;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Vibrator;
import android.support.annotation.ColorInt;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import com.pes.androidmaterialcolorpickerdialog.ColorPicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPickerCallback;

import static android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED;

/*public class MainActivity extends AppCompatActivity implements OnItemSelectedListener {*/
public class MainActivity extends AppCompatActivity {
    int color = 0;
    boolean vibration = false;
    int REQUEST_ACTIVITY = 3;

    // Selecteur des couleurs
    /*
    public volatile Spinner spin;
    public volatile ArrayAdapter<CharSequence> adapterSpin;
    */

    // Bluetooth
    BluetoothAdapter bluetoothAdapter;
    BluetoothSocket bluetoothSocket;
    BluetoothDevice bluetoothDevice;
    boolean btConnected = false;
    boolean stopThreadConnectBoitier = false;

    Thread connectToBoitier;

    // Liste des bt devices
    ArrayList<BluetoothDevice> listBluetoothDevice = new ArrayList<>();
    ArrayList<String> listBluetoothName = new ArrayList<>();

    // BT output & input stream
    static OutputStream bluetoothOutputStream;
    static InputStream bluetoothInputStream;

    // Les objets de l'ecran
    TextView verifPerm;
    Vibrator vib;
    EditText edit;
    EditText editTempo;
    Switch switchVib;
    Button buttonStart;


    Intent intentMain2Activity;
    /*
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:
                color = 0xFFF75A5A;
                spin.setBackgroundColor(color);
                break;

            case 1:
                color = 0xFF4691FF;
                spin.setBackgroundColor(color);
                break;

            case 2:
                color = 0xFFC0FF46;
                spin.setBackgroundColor(color);
                break;
            case 3:
                color = 0xFFF188B8;
                spin.setBackgroundColor(color);
                break;
            case 4:
                color = 0xFFCAB25C;
                spin.setBackgroundColor(color);
                break;
            case 5:
                color = 0xFFFFFA67;
                spin.setBackgroundColor(color);
                break;
            default:
                Toast tbiss = Toast.makeText(getApplicationContext(), "Autre", Toast.LENGTH_LONG);
                tbiss.show();
                break;
        }
    }



    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast t = Toast.makeText(getApplicationContext(), "Choisir une couleur !", Toast.LENGTH_LONG);
        t.show();
    }
    */


    /***********************************************************************
     On Create
     ***********************************************************************/
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("xavier ", "onCreate");
        setContentView(R.layout.activity_main);

        // Init de la liste de BT Ears Have Ears
        listBluetoothName.add("EyesHaveEarsMoniteur");
        listBluetoothName.add("HC-05-MONITEUR");
        listBluetoothName.add("HC-05-MONITEUR-2");

        // Liste des consignes
        intentMain2Activity = new Intent(MainActivity.this, Main2Activity.class);

        // Bluetooth event
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        registerReceiver(bluetoothReceiver, filter);

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        edit = findViewById(R.id.TexteName);
        editTempo = findViewById(R.id.Temporisation);
        switchVib = findViewById(R.id.Vib);
        buttonStart = findViewById(R.id.Start);

        /*
        spin = findViewById(R.id.Spin);
        adapterSpin = ArrayAdapter.createFromResource(this, R.array.Choose_Color, R.layout.spin_item);
        spin.setAdapter(adapterSpin);
        spin.setOnItemSelectedListener(this);
        */
        verifPerm = findViewById(R.id.ValidationPerm);

        //Pour fermer keyboard
        /*View v = findViewById(R.id.form_layout);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getCurrentFocus() != null) {
                    InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                }
            }
        });*/

        //===================================
        // Permissions
        //===================================
        this.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},1);
        this.requestPermissions(new String[]{Manifest.permission.BLUETOOTH},1);

        //=======================================
        // Lecture des paramètres sauvegardés
        //======================================
        final SharedPreferences prefs = getSharedPreferences("Preferences", Context.MODE_PRIVATE);
        final SharedPreferences.Editor ed = prefs.edit();

        edit.setText(prefs.getString("Name", ""));
        editTempo.setText(prefs.getString("Tempo", ""));
        switchVib.setChecked(prefs.getBoolean("vib", false));
        vibration = prefs.getBoolean("vib", false);
        color=prefs.getInt("color",0);
        //spin.setSelection(color);

        Log.i("xavier","Color="+prefs.getInt("color",0));
        Log.i("xavier","name="+prefs.getString("name","??"));

        //======================================
        // Nom moniteur
        //=======================================
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                ed.putString("Name", s.toString()).apply();
            }
        });

        //==================================
        // Temporisation affichage message
        //==================================
        editTempo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                ed.putString("Tempo", s.toString()).apply();
            }
        });
        // =====================
        // Switch vibration
        // =====================
        switchVib.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked)  {
                    vibration = true;
                    vib.vibrate(300);
                    ed.putBoolean("vib", true).apply();
                } else {
                    ed.putBoolean("vib", false).apply();
                    vibration = false;
                }
            }
        });

        //========================================
        // Gestion de la selection de la couleur
        //========================================
        final ColorPicker cp = new ColorPicker(MainActivity.this, Color.red(color), Color.green(color), Color.blue(color));
        Log.i("xavier", "c=" + color + " r= " + String.valueOf(Color.red(color) + " g=" +  Color.green(color) + " b=" + Color.blue(color)));
        cp.setColor(color);

        final Button button = (Button) findViewById(R.id.boutonColorPicker);
        button.setBackgroundColor(cp.getColor());
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i("xavier","boutonColorPicker onclick");
                onButtonOpenColorPreference(cp);
            }
        });

        cp.setCallback(new ColorPickerCallback() {
            @Override
            public void onColorChosen(@ColorInt int color) {
                // Do whatever you want
                // Examples
                button.setBackgroundColor(cp.getColor());
                Log.i("xavier", String.valueOf(color));
            }
        });

        // ==========================
        // Bouton démarrer
        // ===========================
        buttonStart.setEnabled(false);
        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Sauvegarde des paramètres
                    //ed.putInt("color",spin.getSelectedItemPosition());
                    ed.putInt("color",cp.getColor());
                    ed.putString("name",edit.getText().toString());
                    ed.putBoolean("vibration", vibration);
                    ed.putString("Temporisation",editTempo.getText().toString());
                    ed.commit();

                    // Passage des paramètres à l'activté suivante
                    intentMain2Activity.putExtra("name", edit.getText().toString());
                    intentMain2Activity.putExtra("color", cp.getColor());
                    intentMain2Activity.putExtra("vibration", vibration);
                    intentMain2Activity.putExtra("Temporisation", editTempo.getText().toString());
                    startActivityForResult(intentMain2Activity, REQUEST_ACTIVITY);
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    /***********************************************************************
     On Start
     ***********************************************************************/
    @Override
    protected void onStart() {
        super.onStart();
        Log.i("xavier ", "onStart");
        if (findBT()) {
            if (connectToBoitier == null){
                stopThreadConnectBoitier = false;
                connectToBoitier();
            } else if (!connectToBoitier.isAlive()) {
                stopThreadConnectBoitier = false;
                connectToBoitier();
            }
        }
    }

    /***********************************************************************
     *  onStop
     ***********************************************************************/
    @Override
    protected void onStop() {
        Log.i("xavier", "onStop...");
        super.onStop();
    }

    /***********************************************************************
     *  onDestroy
     ***********************************************************************/
    @Override
    protected void onDestroy() {
        Log.i("xavier", "onDestroy...");
        super.onDestroy();
        stopThreadConnectBoitier = true; // Arret thread bt
        try {
            unregisterReceiver(bluetoothReceiver);
            if (bluetoothSocket.isConnected()){
                bluetoothSocket.close();
            }
        } catch (Exception ex) {
            Log.d("xavier", "onDestroy " + ex.toString());
        }
    }

    /***********************************************************************
     *  onResume
     ***********************************************************************/
    @Override
    protected void onResume() {
        Log.i("xavier", "onResume...");
        super.onResume();
    }
    /***********************************************************************
     *   Gestion Bluetooth
     *************************************************************************/
    public boolean findBT() {
        boolean ret = true;
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Log.d("xavier", "findBT Début");
        if (bluetoothAdapter == null) {
            ret = false;
            setToast("Pas de Bluetooth sur le téléphone!");
            Log.d("xavier", "findBT no bt");

        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, 0);
            ret =  false;
            Log.d("xavier", "findBT startActivityForResult");

        }
        return ret;
    }

    // ===============================================================
    // Connexion au boitier LORA/BT
    // ==============================================================
    void connectToBoitier() {
        //new ConnectThread(device)

        connectToBoitier = new Thread(new Runnable() {
            public void run() {
                while ( !btConnected) {

                    if (stopThreadConnectBoitier) {break;}

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            buttonStart.setEnabled(false);
                        }
                    });

                    if (findBT()) {
                        if (findAndConnectBoitier()) {
                            btConnected = true;
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    buttonStart.setEnabled(true);
                                }
                            });

                            setToast("Connecté à " + bluetoothDevice.getName());
                            Log.i("xavier", "connectToBoitier Connecté à " + bluetoothDevice.getName());
                        }
                    }
                }
            }
        });
        connectToBoitier.start();
    }

    //===========================================================
    // Recherche des boitiers BT/LORA
    // HC-05-MONITEUR, HC-05-MONITEUR-2 ou EyesHaveEarsMoniteur
    //===========================================================
    public boolean findAndConnectBoitier() {
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                if (listBluetoothName.contains(device.getName()) ){
                    Log.i("xavier", "findBoitier "+ device.getName() + " trouvé sur le réseau BT.");
                    if (stopThreadConnectBoitier) return false;
                    bluetoothDevice = device;
                    listBluetoothDevice.add(device);
                    if (connectBluetooth()) return true;
                }
            }
        }
        return false;
    }
    //========================================================================
    // Connexion au Bluetooth et create des sockets de communication in & out
    //========================================================================
    public boolean connectBluetooth() {
        boolean ret = false;
        try {
            Log.i("xavier", "connectBluetooth init...");
            setToast("Connexion à " + bluetoothDevice.getName() + "...");

            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(uuid);

            bluetoothSocket.connect();

            bluetoothOutputStream = bluetoothSocket.getOutputStream();
            bluetoothInputStream = bluetoothSocket.getInputStream();
            ret = true;

        } catch (IOException ex) {
            try {bluetoothSocket.close();} catch(IOException exc){
                Log.i("xavier", "connectBluetooth exception" + ex);
                ret = false;

            }
        }
        return ret;
    }

    // ==========================================================
    // Create a BroadcastReceiver for bluetooth related checks
    // ==========================================================
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            Log.i("xavier ", "==>" + action + " on " + device.getName() + "(" + device + ")");

            //We don't want to reconnect to already connected device
            if (!btConnected) {
                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent
                    // Check if the found device is one we had comm with
                    if (listBluetoothName.contains(device.getName())) {
                        connectToBoitier();
                    }
                }
            }
            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                // Check if the connected device is one we had comm with
                if (listBluetoothName.contains(device.getName())) {
                    Log.i("xavier ", "ACTION_ACL_CONNECTED");
                    btConnected = true;
                    setToast("Connecté à " + device.getName());

                }
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {

                // Check if the connected device is one we had comm with
                if (listBluetoothName.contains(device.getName())) {
                    setToast("Déconnexion boitier " + device.getName());
                    btConnected = false;
                    if (!connectToBoitier.isAlive()) {connectToBoitier();};
                }
            }
        }
    };

    /***********************************************************
      Toast on User Interface pour le threads
    ************************************************************ */
    private void setToast(final String value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),value,Toast.LENGTH_LONG).show();
            }
        });
    }

    /***********************************************************
     Open color picker using popup
     ************************************************************ */
    public void onButtonOpenColorPreference( ColorPicker cp ) {
        Log.i("xavier","onButtonOpenColorPreference click ");
        cp.show();
        cp.enableAutoClose(); // Enable auto-dismiss for the dialog

    }
    /***********************************************************
     Resultat dialog autorisation bluetooth
     ************************************************************ */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Log.i("xavier","onActivityResult " + requestCode + " " + resultCode);
        if (resultCode == RESULT_OK) {
            if (findBT()) {
                if (connectToBoitier == null){
                    stopThreadConnectBoitier = false;
                    connectToBoitier();
                } else if (!connectToBoitier.isAlive()) {
                    stopThreadConnectBoitier = false;
                    connectToBoitier();
                }
            }
        }
    }

}