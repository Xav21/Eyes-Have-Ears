package com.example.EyesHaveEarsMoniteur;

import android.content.Context;
import android.content.Intent;
import android.os.Vibrator;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static android.speech.SpeechRecognizer.ERROR_AUDIO;
import static android.speech.SpeechRecognizer.isRecognitionAvailable;

public class Main2Activity extends AppCompatActivity {

    int color = 0;
    int count = 0;
    int b = 0;
    int tempo = 0;

    String idUser = "";
    String name = "";
    String str = "";
    String messageAckno = "";
    String conf = "";

    private static final String TAG = "xavier";

    boolean vibration;
    public boolean stopTheadLectureBluetooth = true;

    byte[] bufferEnv = new byte[512];
    byte[] bufferLect = new byte[512];

    Vibrator vib;

    ListView liste;
    ItemAdaptater itemAdaptater;
    List<ItemModel> listeItem = new ArrayList<>();

    ArrayList<String> idArray = new ArrayList<>();
    ArrayList<String> nameArray = new ArrayList<>();
    ArrayList<Integer> colorArray = new ArrayList<>();

    private SpeechRecognizer sr;

    String getHeure() {
        Date date = new Date();
        SimpleDateFormat formatDate = new SimpleDateFormat("HH:mm:ss");
        return formatDate.format(date);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
            case KeyEvent.KEYCODE_HEADSETHOOK:
                methodeSendVoice();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast t = Toast.makeText(getApplicationContext(), "Parlez", Toast.LENGTH_LONG);
                        t.show();
                    }
                });
                return true;
            default:
                Toast.makeText(getApplicationContext(), String.valueOf(keyCode), Toast.LENGTH_LONG).show();
                //return true;
                return super.dispatchKeyEvent(event);
        }
    }


    void envoiConfiguration(String name, int color, int tempo) {
        int g = (int) (Math.random() * 50 + 1);
        idUser = String.valueOf(g);
        conf = "[:CoNfIg" + ":" + g + ":" + name + ":" + color + ":" + tempo + ":]";
        bufferEnv = conf.getBytes(Charset.defaultCharset());
        try {
            MainActivity.bluetoothOutputStream.write(bufferEnv);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "envoiConfiguration: " + e.toString(), Toast.LENGTH_LONG).show();

        }
    }

    void envoiBluetooth(final String message) {
        try {
            listeItem.add(0, new ItemModel(getHeure(), name,"En cours", message, 0xFFA2A2A2));
            liste.setAdapter(itemAdaptater);

            messageAckno = "[:" + idUser + ":" + message + ":]";
            bufferEnv = messageAckno.getBytes(Charset.defaultCharset());
            MainActivity.bluetoothOutputStream.write(bufferEnv);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "envoiBluetooth: " + e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    void methodeSendVoice() {
        Log.i(TAG, "MethodeSendVoice");
        if (isRecognitionAvailable(getApplicationContext())) {
            try {
                Log.i(TAG, "MethodeSendVoice intentSpeech");
                Intent intentSpeech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                intentSpeech.putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez...");
                intentSpeech.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                intentSpeech.putExtra(RecognizerIntent.EXTRA_RESULTS, 1);
                //intentSpeech.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, 1);
                sr.startListening(intentSpeech);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "methodeSendVoice: " + e, Toast.LENGTH_LONG).show();
            }
        }
    }


    void lectureBluetooth() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "Main2Activity lecture");
                stopTheadLectureBluetooth = false;
                Arrays.fill(bufferLect, (byte) 32);

                while (!stopTheadLectureBluetooth) {
                    try {
                        // Clear buffer
                        Arrays.fill(bufferLect, (byte) 32);

                        // Lecture BT input Stream
                        if (MainActivity.bluetoothInputStream.available() != 0) {
                            // Attente 50ms que le buffer soit bien rempli avant de le lire
                            //Thread.sleep(50);
                            b = readInputStreamWithTimeout(MainActivity.bluetoothInputStream, bufferLect, 4000);
                            //b = MainActivity.bluetoothInputStream.read(bufferLect,0,MainActivity.bluetoothInputStream.available());
                        } else
                            b = -1;

                        // Reception d'une message sur le bt
                        if (b != -1) {
                            Log.i(TAG, str);
                            // Formatage de la trame reçue.
                            str = new String(bufferLect, Charset.defaultCharset());

                            // Vibration sur reception de message
                            if (vibration) vib.vibrate(250);

                            // Decodage de la trame
                            String[] splitStr;
                            splitStr = str.trim().split(":");
                            // ============================================
                            // Configuration==> moniteur en ligne
                            // ============================================
                            if (splitStr[1].equals("CoNfIg")) {
                                try {
                                    idArray.add(splitStr[2]);
                                    nameArray.add(splitStr[3]);
                                    colorArray.add(Integer.decode(splitStr[4]));
                                    tempo = Integer.decode(splitStr[5]);
                                    listeItem.add(0, new ItemModel(getHeure(), nameArray.get(count), " en ligne" ,nameArray.get(count) + " en ligne." , colorArray.get(count)));
                                    //ItemModel(String date, String name, String status, String text, int color)

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), "lectureBluetooth/config=" + e.toString(), Toast.LENGTH_LONG).show();
                                }
                            }
                            // ============================================
                            // Message reçu
                            // ============================================
                            else {
                                ItemModel item;
                                item = listeItem.get(0);
                                if (getName(splitStr[1]).equals(item.getName()) && splitStr[2].equals(item.getText())) {
                                    item.setStatus("Ok");
                                    item.setColor(getColor(splitStr[1]));

                                } else {
                                    listeItem.add(0, new ItemModel( getHeure(), getName(splitStr[1]), "En cours", splitStr[2],  getColor(splitStr[1])));

                                }
                                Log.i(TAG,"1="+ item.getDate()+ " 2="+item.getName()+" 3="+item.getStatus()+" 4="+item.getColor()+" 5="+item.getText());
                            }
                        }

                        // Mise à jour de la liste
                        runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    itemAdaptater.notifyDataSetChanged();
                                }
                        });

                        Thread.sleep(10);

                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "lectureBluetooth " + e.toString(), Toast.LENGTH_LONG).show();

                        }
                }

            }
        }).start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Log.i(TAG, "Main2Activity onCreate");

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        Intent intent = getIntent();
        color = intent.getIntExtra("color", 0);
        name = intent.getStringExtra("name");
        vibration = intent.getBooleanExtra("vibration", false);
        tempo = Integer.decode(intent.getStringExtra("Temporisation"));

        //Toast.makeText(getApplicationContext(), name + String.valueOf(color) + String.valueOf(vibration) + tempo, Toast.LENGTH_LONG).show();

        liste = findViewById(R.id.ListeMessage);

        /*liste.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                //v.getParent().requestDisallowInterceptTouchEvent(true);
                Log.i("xavier", "Main2Activity setOnTouchListener...");
                return false;
            }
        });*/

        itemAdaptater = new ItemAdaptater(Main2Activity.this, listeItem);
        liste.setAdapter(itemAdaptater);

        lectureBluetooth();
        envoiConfiguration(name, color, tempo);

        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new listenerRecongnition());

        Button Test = findViewById(R.id.synchroniser);
        Test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                envoiConfiguration(name, color, tempo);
            }
        });
    }


    @Override
    protected void onDestroy() {
        Log.i("xavier", "Main2Activity onDestroy...");
        super.onDestroy();
        stopTheadLectureBluetooth = true;
        sr.destroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==50) {
            if (resultCode == RESULT_OK && null != data) {
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                Toast.makeText(getApplicationContext(), result.get(0), Toast.LENGTH_LONG).show();
                String inter = result.get(0);
                envoiBluetooth(/*NumID + ":" + */inter);
            } else if (resultCode == ERROR_AUDIO) {
                this.finish();
            }
        }
    }


    class listenerRecongnition implements RecognitionListener {
        int nbRecognition = 0;

        public void onReadyForSpeech(Bundle params) {
            Log.i(TAG, "onReadyForSpeech");
        }

        public void onBeginningOfSpeech() {
            Log.i(TAG, "onBeginningOfSpeech");
            nbRecognition = 0;
        }

        public void onRmsChanged(float rmsdB) {
            //Log.i(TAG, "onRmsChanged");
        }

        public void onBufferReceived(byte[] buffer) {
            Log.i(TAG, "onBufferReceived");
        }

        public void onEndOfSpeech() {
            Log.i(TAG, "onEndofSpeech");
            nbRecognition = 0;
        }

        public void onError(int error) {
            Log.i(TAG, "error " + error);
        }

        public void onResults(Bundle results) {
            String str;
            Log.i(TAG, "onResults " + results+ " nbRecognition="+nbRecognition);
            ArrayList<String> data = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (data != null && nbRecognition == 0) {
                str = data.get(0);
                envoiBluetooth(/*NumID + ":" + */str);
            }
            nbRecognition++;
        }

        public void onPartialResults(Bundle partialResults) {
            Log.i(TAG, "onPartialResults");
        }

        public void onEvent(int eventType, Bundle params) {
            Log.i(TAG, "onEvent " + eventType);
        }
    }

    String getName(String id) {
        String ret ="??";
        for (int i = 0; i < idArray.size(); i++) {
            if (idArray.get(i).equals(id)) {
                ret = nameArray.get(i);
            }
        }
        return ret;
    }


    int getColor(String id) {
        int ret = 0xFFFE1010;
        for (int i = 0; i < idArray.size(); i++) {
            if (idArray.get(i).equals(id)) {
                ret = colorArray.get(i);
            }
        }
        return ret;
    }

    /****************************************************************
     * readInputStreamWithTimeout
     * @param is  input stream
     * @param b  result byte array
     * @param timeoutMillis
     * @return -1 nothing other size
     * @throws IOException
     */
    public static int readInputStreamWithTimeout(InputStream is, byte[] b, int timeoutMillis)
            throws IOException {
        int bufferOffset = 0;
        long maxTimeMillis = System.currentTimeMillis() + timeoutMillis;
        //while (System.currentTimeMillis() < maxTimeMillis && bufferOffset < b.length) {
        while (System.currentTimeMillis() < maxTimeMillis && !findEndMessageDelimiter(b) ) {
            int readLength = java.lang.Math.min(is.available(),b.length-bufferOffset);
            // can alternatively use bufferedReader, guarded by isReady():
            int readResult = is.read(b, bufferOffset, readLength);
            if (readResult == -1) break;
            bufferOffset += readResult;
        }
        return bufferOffset;

        }

    private static boolean findEndMessageDelimiter (byte[] buffer) {
        for (int j = 0; j < buffer.length; j++) {
            if (buffer[j] == 0x5D) {
                return true;
            }
        }
        return false;
    }
}
