package com.example.EyesHaveEarsMoniteur;

public class ConsignesModel {
    private String date;
    private String name;
    private String status;
    private String text;
    private int color;

    public ConsignesModel(String date, String name, String status, String text, int color){
        this.date = date;
        this.name = name;
        this.status = status;
        this.text = text;
        this.color = color;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getStatus() {
        return status;
    }

    public void setText(String text) {
        this.text = text;
    }
    public String getText() {
        return text;
    }

    public void setColor(int color) {
        this.color = color;
    }
    public int getColor() {
        return color;
    }
}