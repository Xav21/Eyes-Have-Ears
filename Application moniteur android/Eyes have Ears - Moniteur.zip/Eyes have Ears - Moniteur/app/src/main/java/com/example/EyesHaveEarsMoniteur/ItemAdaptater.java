package com.example.EyesHaveEarsMoniteur;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

public class ItemAdaptater extends ArrayAdapter<ItemModel> {

    public ItemAdaptater(Context context, List<ItemModel> item){
        super(context, 0, item);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.liste_item, parent, false);
        }

        ItemViewHolder itemViewHolder = (ItemViewHolder) convertView.getTag();

        if(itemViewHolder == null){
            itemViewHolder = new ItemViewHolder();
            itemViewHolder.date = convertView.findViewById(R.id.heure);
            itemViewHolder.name = convertView.findViewById(R.id.name);
            itemViewHolder.text = convertView.findViewById(R.id.textMessage);
            itemViewHolder.status = convertView.findViewById(R.id.Eta);
            itemViewHolder.color = convertView.findViewById(R.id.Background);
            convertView.setTag(itemViewHolder);
        }

        ItemModel item = getItem(position);

        itemViewHolder.date.setText(item.getDate());
        itemViewHolder.name.setText(item.getName());
        itemViewHolder.text.setText(item.getText());
        itemViewHolder.status.setText(item.getStatus());
        itemViewHolder.color.setBackgroundColor(item.getColor());


        return convertView;
        //return super.getView(position, convertView, parent);
    }

    private class ItemViewHolder{
        public TextView date;
        public TextView name;
        public TextView text;
        public TextView status;
        public RelativeLayout color;
    }
}