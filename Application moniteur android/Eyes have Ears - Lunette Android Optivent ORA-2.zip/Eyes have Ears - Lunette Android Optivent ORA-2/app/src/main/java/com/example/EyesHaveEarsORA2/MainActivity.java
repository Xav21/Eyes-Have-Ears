package com.example.EyesHaveEarsORA2;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends Activity {

    int REQUEST_ENABLE_BT = 0;
    int REQUEST_ACTIVITY = 3;
    String TAG = "xavier";
    boolean stopThreadLectureBluetooth = false;
    byte[] bufferLectureBluetooth = new byte[512];

    BluetoothAdapter bluetoothAdapter;
    static BluetoothSocket bluetoothSocket;
    boolean btConnected = false;
    static OutputStream bluetoothOutputStream = null;
    static InputStream bluetoothInputStream = null;
    Intent enableBtIntent;

    // Liste des bt devices
    ArrayList<String> listBluetoothName = new ArrayList<>();

    // Les object UI
    ListView liste;
    ItemAdaptater itemAdaptater;
    List<ItemModel> listeItem = new ArrayList<>();
    boolean vibration;
    Vibrator vib;

    ArrayList<String> idArray = new ArrayList<>();
    ArrayList<String> nameArray = new ArrayList<>();
    ArrayList<Integer> colorArray = new ArrayList<>();

    int tempo = 15;
    int nbClearConsigneCall = 0;
    
    /***********************************************************************
     *  onCreate
     ***********************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //intent = new Intent(MainActivity.this, Main2Activity.class);
        enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        // Bluetooth event
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        registerReceiver(bluetoothReceiver, filter);

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        // Gestion de la consigne par une liste.
        liste = findViewById(R.id.consignes);
        itemAdaptater = new ItemAdaptater(MainActivity.this, listeItem);
        liste.setAdapter(itemAdaptater);
        listeItem.add(0, new ItemModel( "" ,"" ,0));


        //Configuration du Bluetooth
        listBluetoothName.add("HC-05");
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(!bluetoothAdapter.isEnabled())
            BT_ON();
        else if(bluetoothAdapter.isEnabled())
            ConfigurationBT();

    }
    /***********************************************************************
     *  onDestroy
     ***********************************************************************/

    @Override
    protected void onDestroy() {
        Log.i("xavier", "onDestroy...");
        super.onDestroy();

        stopThreadLectureBluetooth = true;
        unregisterReceiver(bluetoothReceiver);
        try {
            bluetoothSocket.close();
        } catch (IOException ex) {
            Log.d("xavier", ex.toString());
        }
    }

    /***********************************************************
    * Gestion de la connexion Bluetooth
    ************************************************************/
    //Create a BroadcastReceiver for bluetooth related checks

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            Log.i("xavier ", "==>" + action + " on " + device.getName() + "(" + device + ")");

            //We don't want to reconnect to already connected device
            if (!btConnected) {
                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent

                    // Check if the found device is one we had comm with
                    if (listBluetoothName.contains(device.getName())) {
                        ConfigurationBT();
                    }
                }
            }
            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                // Check if the connected device is one we had comm with
                if (listBluetoothName.contains(device.getName())) {
                    Log.i("xavier ", "ACTION_ACL_CONNECTED");
                    btConnected = true;
                    setToast("Connecté à " + device.getName());

                }
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {

                // Check if the connected device is one we had comm with
                if (listBluetoothName.contains(device.getName())) {
                    setToast("Déconnexion boitier " + device.getName());
                    stopThreadLectureBluetooth = true;
                    btConnected = false;
                    bluetoothInputStream = null;
                    bluetoothOutputStream = null;
                    ConfigurationBT();
                }
            }
        }
    };

    void BT_ON(){
        setToast("Autorisation à l'accès au Bluetooth requise" );
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }

    void ConfigurationBT(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(bluetoothAdapter.isEnabled()){
                    Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

                    if (pairedDevices.size() > 0) {
                        // There are paired devices. Get the name and address of each paired device.
                        for (BluetoothDevice device : pairedDevices) {
                            String deviceName = device.getName();
                            //String deviceHardwareAddress = device.getAddress(); // MAC address

                            if (listBluetoothName.contains(deviceName)) {
                                Log.i(TAG,"HC-05 trouvé");
                                setToast("Tentative de connexion au boitier pilote  " + deviceName + "...");

                                ConnectThread connect = new ConnectThread(device);
                                connect.run();
                                bluetoothSocket = connect.thisSocket;
                                if(connect.thisSocket.isConnected()){
                                    setToast("Connexion ok au boitier pilote " + deviceName );
                                    try {
                                        // Lancement de la lecture
                                        bluetoothOutputStream = connect.thisSocket.getOutputStream();
                                        bluetoothInputStream = connect.thisSocket.getInputStream();
                                        readBluetoothConsignes();

                                    }catch(Exception e){
                                        Log.i(TAG,e.toString());
                                        setToast(e.toString());
                                    }
                                }else {
                                    Log.i(TAG,"Echec connexion boitier pilote");
                                    setToast("Erreur de connexion au boitier pilote " + deviceName + "...");
                                    ConfigurationBT();
                                }
                            }
                        }
                    }
                }
            }
        }).start();
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket thisSocket;

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;

            try {
                //00001101-0000-1000-8000-00805f9b34fb
                tmp = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"));
            } catch (IOException e) {
                Log.e("TEST", "Can't connect to service");
            }
            thisSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it otherwise slows down the connection.
            bluetoothAdapter.cancelDiscovery();

            try {
                thisSocket.connect();
                Log.d("TEST", "Connected to shit");
            } catch (IOException connectException) {
                try {
                    thisSocket.close();
                } catch (IOException closeException) {
                    Log.e("TEST", "Can't close socket");
                }
                return;
            }
            bluetoothSocket = thisSocket;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_ENABLE_BT){
            if(resultCode == RESULT_OK){
                ConfigurationBT();
            }else
                BT_ON();
        }

        if(requestCode == REQUEST_ACTIVITY){
            if(bluetoothAdapter.isEnabled())
                ConfigurationBT();
            else
                BT_ON();
        }
    }

    /***********************************************************
     Toast on User Interface pour le threads
     ************************************************************ */
    private void setToast(final String value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),value,Toast.LENGTH_LONG).show();
            }
        });
    }
    /***********************************************************
     Toast on User Interface pour le threads
     ************************************************************ */
    private void displayConsigne (final String str, final String moniteur){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //consigne.setText(str);
                ItemModel item = listeItem.get(0);
                item.setTwo(str);
                item.setOne(moniteur);
                liste.setAdapter(itemAdaptater);
            }
        });
    }
    /***********************************************************
     Toast on User Interface pour le threads
     ************************************************************ */

    String getName(String id) {
        String ret ="??";
        for (int i = 0; i < idArray.size(); i++) {
            if (idArray.get(i).equals(id)) {
                ret = nameArray.get(i);
            }
        }
        return ret;
    }

    /***********************************************************
     Thread principal de lecture des consignes sur bluetooth
     ************************************************************ */
    void readBluetoothConsignes() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                stopThreadLectureBluetooth = false;

                while (!stopThreadLectureBluetooth) {
                    int b=0;
                    try {
                        // Lecture bt si plus de 5 caractères reçus
                        if (bluetoothInputStream.available() > 5) {
                            Log.i(TAG, String.valueOf(bluetoothInputStream.available()));

                            // Clear buffer
                            Arrays.fill(bufferLectureBluetooth, (byte) 32);

                            //b = readInputStreamWithTimeout(bluetoothInputStream, bufferLect, 200);
                            int bufferOffset = 0;
                            long maxTimeMillis = System.currentTimeMillis() + 200;
                            while (System.currentTimeMillis() < maxTimeMillis && bufferOffset < bufferLectureBluetooth.length ) {
                                int readLength = Math.min(bluetoothInputStream.available(), bufferLectureBluetooth.length - bufferOffset);
                                // can alternatively use bufferedReader, guarded by isReady():
                                int readResult = bluetoothInputStream.read(bufferLectureBluetooth, bufferOffset, readLength);
                                if (readResult == -1) break;
                                bufferOffset += readResult;
                            }
                        } else
                            b = -1;

                    } catch (Exception e) {
                        Log.i(TAG,e.toString());
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                    String str = new String(bufferLectureBluetooth, Charset.defaultCharset());
                    if (b != -1) {
                        Log.i(TAG,str);

                        //Vibration sur reception de message todo: vibration non implémentée coté lunette
                        if (vibration)
                            vib.vibrate(250);

                        // Decodage de la trame
                        try {
                            String[] splitStr = str.trim().split(":");
                        // ============================================
                        // Configuration==> moniteur en ligne
                        // ============================================
                            if (splitStr[0].equals("[")  && splitStr[1].equals("CoNfIg")) {
                                    idArray.add(splitStr[2]);
                                    nameArray.add(splitStr[3]);
                                    colorArray.add(Integer.decode(splitStr[4]));
                                    tempo = Integer.decode(splitStr[5]);
                                    str = "Moniteur " + splitStr[3] + " en ligne";
                                    displayConsigne(str, "");
                            } else  {
                            //==============================================
                            //  Consigne moniteur à afficher
                            //==============================================
                                if (splitStr[0].equals("[") && splitStr[3].equals("]") ) {
                                    displayConsigne(splitStr[2], getName(splitStr[1]));
                                }
                            }
                            // effacement de la consigne après tempo secondes
                            clearConsigne(tempo );

                            // Renvoi du message pour acquitement
                            bluetoothOutputStream.write(bufferLectureBluetooth);

                        } catch (Exception e) {
                            Log.i(TAG,"lecture decodage trame "+ e.toString());
                        }
                    }
                    // Attente de 10ms
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    /***********************************************************
     clear consigne
     ************************************************************ */
    void clearConsigne(final int second){
        new Thread(new Runnable() {
            @Override
            public void run() {
                nbClearConsigneCall++;
                long clearConsigneTime = System.currentTimeMillis() + (second * 1000);
                while (System.currentTimeMillis() < clearConsigneTime) {
                    try {
                            Thread.sleep(1);
                        }
                    catch (Exception e){
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                        }
                }
                nbClearConsigneCall--;
                if (nbClearConsigneCall == 0 ) {
                    displayConsigne("","");
                    Log.i(TAG,"clearConsigne");
                }
            }
        }).start();
    }

}

