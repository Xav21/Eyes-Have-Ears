package com.example.EyesHaveEarsMoniteur;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

public class ItemAdaptater extends ArrayAdapter<ItemModel> {

    public ItemAdaptater(Context context, List<ItemModel> item){
        super(context, 0, item);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.liste_item, parent, false);
        }

        ItemViewHolder IV = (ItemViewHolder) convertView.getTag();

        if(IV == null){
            IV = new ItemViewHolder();
            IV.one = convertView.findViewById(R.id.H_Name);
            IV.two = convertView.findViewById(R.id.textMessage);
            IV.three = convertView.findViewById(R.id.Eta);
            IV.four = convertView.findViewById(R.id.Background);
            convertView.setTag(IV);
        }

        ItemModel item = getItem(position);

        IV.one.setText(item.getOne());
        IV.two.setText(item.getTwo());
        IV.three.setText(item.getThree());
        IV.four.setBackgroundColor(item.getFour());


        return convertView;
        //return super.getView(position, convertView, parent);
    }

    private class ItemViewHolder{
        public TextView one;
        public TextView two;
        public TextView three;
        public RelativeLayout four;
    }
}