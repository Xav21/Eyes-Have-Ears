package com.example.goldeneyeuser;

import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbEndpoint;
import android.os.Vibrator;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    int color = 0xFFFFFFFF;
    int count = 0;
    int compteurTempo = 0;
    int b =0;
    int tempo = 5;

    String name;
    String str = "";
    String[] splitStr = new String[3];
    String chaineLong = "";
    String nameLong = "";

    boolean vibration;
    boolean stopLect = false;
    boolean check = false;
    boolean actuListe = false;
    boolean notFind = false;
    boolean stock = false;

    byte[] bufferEnv = new byte[100];
    byte[] bufferLect = new byte[100];

    Vibrator vib;
    ListView liste;
    ItemAdaptater IA;
    TextView Name_Be;

    List<ItemModel> LItem = new ArrayList<ItemModel>();

    ArrayList<String> NumId = new ArrayList<>();
    ArrayList<String> NameId = new ArrayList<>();
    ArrayList<Integer> ColorId = new ArrayList<>();

    //Intent intentSpeech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

    String Heure(){
        Date date = new Date();
        SimpleDateFormat formatDate = new SimpleDateFormat("HH:mm:ss");
        return formatDate.format(date);
    }

    void MethodeCheckEnvoi(final String message){
        new Thread(new Runnable() {
            @Override
            public void run() {
                bufferEnv = message.getBytes(Charset.defaultCharset());
                try {
                    MainActivity.m.write(bufferEnv);
                }catch(Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }).start();
    }

    void Lecture(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                stopLect = true;
                while (stopLect) {
                    try{
                        if(MainActivity.l.available() != 0)
                            b = MainActivity.l.read(bufferLect);
                        else
                            b = -1;
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                    str = new String(bufferLect, Charset.defaultCharset());

                    if(b != -1) {
                        actuListe = true;
                        //stopTempo = true;
                        if(vibration)
                            vib.vibrate(250);
                        splitStr = str.trim().split(":", 5);
                        if(splitStr[0].equals("CoNfIg")){
                            try {
                                NumId.add(count, splitStr[1]);
                                NameId.add(count, splitStr[2]);
                                ColorId.add(count, Integer.decode(splitStr[3]));
                                tempo = Integer.decode(splitStr[4]);

                                //Name_Be.setText(NameId.get(count));
                                LItem.add(0, new ItemModel("", "Configuration: " + NameId.get(count) + " OK", color));
                                Temporisation(tempo);
                                count++;
                            }catch(Exception e){
                                LItem.add(new ItemModel(" ", e.toString(), color));
                            }
                        }else if(splitStr[0].equals("DeBuT")){
                            stock = true;
                        }else if(splitStr[0].equals("FiN")){
                            stock = false;
                            LItem.add(new ItemModel(Heure() + " " + nameLong, chaineLong, color));
                            Temporisation(tempo);
                            chaineLong = "";

                        }else{
                            try {
                                //MethodeCheckEnvoi("1");
                                notFind = true;
                                for(int i = 0; i < NumId.size(); i++) {
                                    if(splitStr[0].equals(NumId.get(i))) {
                                        if(stock) {
                                            chaineLong = chaineLong.concat(splitStr[1]);
                                            nameLong = NameId.get(i);
                                        }
                                        else {
                                            LItem.add(0, new ItemModel(Heure() + " " + NameId.get(i), splitStr[1], color));
                                            //Name_Be.setText(nameLong);
                                            Temporisation(tempo);
                                        }
                                        notFind = false;
                                        break;
                                    }
                                }

                                if(notFind){
                                    LItem.add(0, new ItemModel(Heure() + " " + "Inconnu", str, color));
                                    Temporisation(tempo);
                                    notFind = false;
                                }
                            }catch (Exception e){
                                LItem.add(new ItemModel(" ", e.toString(), color));
                            }
                        }
                        for(int i = 0; i < bufferLect.length; i++){
                            bufferLect[i] = 0;
                        }
                    }

                    if(actuListe) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                liste.setAdapter(IA);
                            }
                        });
                        actuListe = false;
                        //stopTempo = false;
                    }

                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                }
            }
        }).start();
    }

    void Temporisation(/*final int position,*/ final int temps){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (compteurTempo <= temps) {
                    try {
                        Thread.sleep(1000);
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                    /*while(stopTempo){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(Main2Activity.this, "Dans while tempo", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }*/
                    compteurTempo++;
                }
                LItem.remove(LItem.size() - 1);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        liste.setAdapter(IA);
                    }
                });
                compteurTempo = 0;
            }
        }).start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        liste = findViewById(R.id.ListeMessage);
        Name_Be = findViewById(R.id.Name_Below);

        IA = new ItemAdaptater(Main2Activity.this, LItem);

        //Pour tester les couleurs
        /*LItem.add(new ItemModel("", "Couleur Blanche", 0xFFFFFFFF));
        LItem.add(new ItemModel("", "Couleur Jaune", 0xFFFFFF00));*/

        liste.setAdapter(IA);
        Lecture();

        /*Button stop = findViewById(R.id.Stop);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check = false;
                stopLect = false;
                try{
                    MainActivity.bluetoothSocket.close();
                    Thread.sleep(1000);
                    finish();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });*/

        Button Test = findViewById(R.id.Test);
        Test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String test = "Coucou";
                bufferEnv = test.getBytes(Charset.defaultCharset());
                try {
                    MainActivity.m.write(bufferEnv);
                }catch(Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        try {
            MainActivity.bluetoothSocket.close();
            Thread.sleep(200);
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
        super.onBackPressed();
    }
}
