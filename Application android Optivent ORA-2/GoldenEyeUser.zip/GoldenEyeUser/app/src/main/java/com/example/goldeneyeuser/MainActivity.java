package com.example.goldeneyeuser;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    int REQUEST_ENABLE_BT = 0;
    int REQUEST_ACTIVITY = 3;

    BluetoothAdapter bluetoothAdapter;
    static BluetoothSocket bluetoothSocket;

    static OutputStream m = null;
    static InputStream l = null;

    Intent intent;
    Intent enableBtIntent;

    TextView VerifPerm;

    void BT_ON(){
        VerifPerm.setText("Permission Denied");
        VerifPerm.setTextColor(0xFFFF0000);
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }

    void ConfigurationBT(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(bluetoothAdapter.isEnabled()){
                    Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

                    if (pairedDevices.size() > 0) {
                        // There are paired devices. Get the name and address of each paired device.
                        for (BluetoothDevice device : pairedDevices) {
                            String deviceName = device.getName();
                            //String deviceHardwareAddress = device.getAddress(); // MAC address

                            if (deviceName.equals("HC-05")) {
                                ConnectThread connect = new ConnectThread(device);
                                connect.run();
                                bluetoothSocket = connect.thisSocket;
                                if(connect.thisSocket.isConnected()){
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            VerifPerm.setText("Connection Réussite");
                                            VerifPerm.setTextColor(0xFF00FF00);
                                        }
                                    });

                                    try {
                                        m = connect.thisSocket.getOutputStream();
                                        l = connect.thisSocket.getInputStream();

                                        startActivity(intent);
                                    }catch(Exception e){
                                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                                    }
                                }else {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            VerifPerm.setText("Echec Connection");
                                            VerifPerm.setTextColor(0xFFFF0000);
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }).start();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intent = new Intent(MainActivity.this, Main2Activity.class);
        enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

        VerifPerm = findViewById(R.id.ValidationPerm);

        //Configuration du Bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if(!bluetoothAdapter.isEnabled())
            BT_ON();
        else if(bluetoothAdapter.isEnabled())
            ConfigurationBT();

        /*Button blue = findViewById(R.id.blue);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bluetoothAdapter.isEnabled() && !bluetoothSocket.isConnected())
                    ConfigurationBT();
                else if(!bluetoothAdapter.isEnabled())
                    BT_ON();
                else{
                    try{
                        bluetoothSocket.close();
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                }
            }
        });*/

        Button SwitchActi = findViewById(R.id.Start);
        SwitchActi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //startActivity(intent);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket thisSocket;
        private final BluetoothDevice thisDevice;

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            thisDevice = device;

            try {
                //00001101-0000-1000-8000-00805f9b34fb
                tmp = thisDevice.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"));
            } catch (IOException e) {
                Log.e("TEST", "Can't connect to service");
            }
            thisSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it otherwise slows down the connection.
            bluetoothAdapter.cancelDiscovery();

            try {
                thisSocket.connect();
                Log.d("TESTING", "Connected to shit");
            } catch (IOException connectException) {
                try {
                    thisSocket.close();
                } catch (IOException closeException) {
                    Log.e("TEST", "Can't close socket");
                }
                return;
            }

            bluetoothSocket = thisSocket;

        }
        public void cancel() {
            try {
                thisSocket.close();
            } catch (IOException e) {
                Log.e("TEST", "Can't close socket");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_ENABLE_BT){
            if(resultCode == RESULT_OK){
                ConfigurationBT();
            }else
                BT_ON();
        }

        if(requestCode == REQUEST_ACTIVITY){
            if(bluetoothAdapter.isEnabled())
                ConfigurationBT();
            else
                BT_ON();
        }
    }
}
